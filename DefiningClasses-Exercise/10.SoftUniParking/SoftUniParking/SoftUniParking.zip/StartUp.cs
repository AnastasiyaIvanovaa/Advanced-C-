﻿using System;

namespace SoftUniParking
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Parking parking = new Parking(1);
        }
    }
}
