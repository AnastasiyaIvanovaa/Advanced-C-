﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCountMethodString
{
    public class Box<T>
        where T: IComparable
    {
        public Box(T value)
        {
            this.Value = value;
        }
        public T Value { get; set; }

        public int Bigger(List<Box<T>> boxes, T value)
        {
            int count = 0;
            foreach (var item in boxes)
            {
               int res= this.Value.CompareTo(value);
                if (res > 0)
                {
                    count++;
                }
            }
            return count;
        }
    }
}
